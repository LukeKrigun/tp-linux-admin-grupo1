
#!/bin/bash

show_help(){
cat <<EOF
Uso: $(basename $0) -o ORIGEN -d DESTINO

	-o DIR Directorio que se va a backupear (Por ejemplo /var/log)
	-d DIR Directorio destino donde guardar el tar.gz (Por ejemplo /backup_dir)
	-h Muestra esta ayuda
EOF
exit 0

}

# leer opciones
while getopts "o:d:h" opt; do
	case $opt in 
	o) ORIGEN="$OPTARG" ;;
	d) DESTINO="$OPTARG" ;;
	h|\?) show_help ;;
	esac

done

#validar obligatorias

if [ -z "$ORIGEN" ] || [ -z "$DESTINO" ]; then
	echo "ERROR: Debes especificar -o ORIGEN y -d DESTINO" >&2
	show_help
fi

# validar que el directorio de origen existe
if [ ! -d "$ORIGEN" ]; then
	echo "ERROR: El origen '$ORIGEN' no existe" >&2
	exit 1
fi

# validar el destino montado (es una particion)
if ! mountpoint -q "$DESTINO"; then
	echo "ERROR: El destino '$DESTINO' no está montado o no existe" >&2
	exit 1
fi 


# Generar nombre de archivo con fecha YYYYMMDD
FECHA=$(date +%Y%m%d)
NOM=$(basename "$ORIGEN")
ARCH="${NOM}_bkp_${FECHA}.tar.gz"

# Crear el backup
tar czf "${DESTINO}/${ARCH}" -C "$(dirname "$ORIGEN")" "$NOM" \
	&& echo "Backup creado: ${DESTINO}/${ARCH}"|| \
	{ echo "FALLO al crear el backup" >&2; exit 2; }







